// import {FC} from "react"

// interface Props {
//    id : string,
//    title : string
// }

// const SingleQuiz = ({id,title}:Props)=>{
//   return(
//     <h1>{id}{title}</h1>
//   )
// }

// export default SingleQuiz;